训练所用的数据，包括标注数据和用户词典。

- [train.json](https://github.com/bojone/SPACES/blob/main/datasets/train.json)：官方提供的训练数据（前5条）；
- [user_dict.txt](https://github.com/bojone/SPACES/blob/main/datasets/user_dict.json)：官方提供的补充词典（加入到jieba分词和预训练模型中）；
- [user_dict_2.txt](https://github.com/bojone/SPACES/blob/main/datasets/user_dict_2.json)：自己整理的词典（这部分词在jieba自带词典中，用于加入到预训练模型中）。
